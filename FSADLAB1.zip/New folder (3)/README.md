# FSAD Exam Spring Boot Application

This repository contains a simple Spring Boot project demonstrating POST and GET operations
on an `Order` entity using JPA. It follows the package structure `com.klef.fsad.exam` with
subpackages `model`, `repository`, `service`, and `controller` as required by the exam.
The database name is `fsadexam`, configured in `application.properties`.

## Features

- **Order** entity with fields `orderId`, `name`, `date`, `status`.
- Manual provision of `orderId` is required for POST requests.
- JPA repository, service, and REST controller layers.
- Validation and error handling in controller.
- H2 database configured for quick testing.

## Running the application

```bash
# from project root
mvn clean package
java -jar target/fsadexam-0.0.1-SNAPSHOT.jar
```

Application will start on `http://localhost:8080`.

### Endpoints

- `POST /api/orders` - Create a new order. JSON body must include `orderId`, `name`, `date` (YYYY-MM-DD), and `status`.
- `GET /api/orders` - Retrieve all orders.
- `GET /api/orders/{id}` - Retrieve order by ID.

### Example cURL

```bash
curl -X POST http://localhost:8080/api/orders \
  -H "Content-Type: application/json" \
  -d '{"orderId":1,"name":"Widget","date":"2026-03-10","status":"NEW"}'

curl http://localhost:8080/api/orders
```

### Testing

Use [Postman](https://www.postman.com/) or `curl` as shown above.

## GitHub repository

To push this code to GitHub:

1. Create a new repository on GitHub (e.g. `fsadexam`).
2. In your local project folder:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/<your-username>/fsadexam.git
   git push -u origin main
   ```

Replace `<your-username>` with your GitHub username.

Once pushed, share the repository link: `https://github.com/<your-username>/fsadexam`.

## Notes

This solution is "advanced" by including validation checks, layered architecture,
and an H2 console for inspecting the database at `http://localhost:8080/h2-console`.

Feel free to switch the database to MySQL or another relational DB by updating `application.properties`.
